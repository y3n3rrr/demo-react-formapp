using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static List<User> kullanicilar = new List<User>();

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(kullanicilar);
        }

        [HttpPost(Name = "kullanicikayit")]
        public IActionResult Post([FromBody] User user)
        {
            kullanicilar.Add(user);
            return Ok();
        }
    }
}